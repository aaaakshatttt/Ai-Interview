-- PrashnAI schema
create extension if not exists "pgcrypto";

-- Candidates
create table if not exists candidates (
  id uuid primary key default gen_random_uuid(),
  auth_user_id uuid references auth.users(id) on delete cascade, -- owner, drives RLS
  name text,
  email text,
  resume_url text,
  resume_text text,
  resume_analysis jsonb,
  created_at timestamptz default now()
);

-- Interview sessions
create table if not exists interview_sessions (
  id uuid primary key default gen_random_uuid(),
  candidate_id uuid references candidates(id) on delete cascade,
  role_title text,
  status text default 'in_progress', -- in_progress | completed | abandoned
  started_at timestamptz default now(),
  completed_at timestamptz
);

-- Individual Q&A turns
create table if not exists interview_turns (
  id uuid primary key default gen_random_uuid(),
  session_id uuid references interview_sessions(id) on delete cascade,
  question_index int,
  question_text text,
  answer_text text,
  answer_audio_url text,
  duration_seconds numeric,
  pitch_mean numeric,
  pitch_variance numeric,
  pause_count int,
  avg_pause_ms numeric,
  volume_mean numeric,
  confidence_score numeric,
  created_at timestamptz default now()
);

-- Final results
create table if not exists interview_results (
  id uuid primary key default gen_random_uuid(),
  session_id uuid references interview_sessions(id) on delete cascade,
  overall_score numeric,
  passed boolean,
  per_question_scores jsonb,
  strengths text[],
  weaknesses text[],
  improvement_plan text,
  confidence_rating text,
  confidence_explanation text,
  created_at timestamptz default now()
);

-- Indexes
create index if not exists idx_sessions_candidate on interview_sessions(candidate_id);
create index if not exists idx_turns_session on interview_turns(session_id);
create index if not exists idx_results_session on interview_results(session_id);

-- ============ RLS ============
alter table candidates enable row level security;
alter table interview_sessions enable row level security;
alter table interview_turns enable row level security;
alter table interview_results enable row level security;

-- Candidates: a user can only see/modify their own candidate row
create policy "candidates_select_own" on candidates
  for select using (auth.uid() = auth_user_id);
create policy "candidates_insert_own" on candidates
  for insert with check (auth.uid() = auth_user_id);
create policy "candidates_update_own" on candidates
  for update using (auth.uid() = auth_user_id);

-- Sessions: only for sessions belonging to the caller's candidate row
create policy "sessions_select_own" on interview_sessions
  for select using (
    candidate_id in (select id from candidates where auth_user_id = auth.uid())
  );
create policy "sessions_insert_own" on interview_sessions
  for insert with check (
    candidate_id in (select id from candidates where auth_user_id = auth.uid())
  );
create policy "sessions_update_own" on interview_sessions
  for update using (
    candidate_id in (select id from candidates where auth_user_id = auth.uid())
  );

-- Turns: only for turns belonging to caller's own sessions
create policy "turns_select_own" on interview_turns
  for select using (
    session_id in (
      select s.id from interview_sessions s
      join candidates c on c.id = s.candidate_id
      where c.auth_user_id = auth.uid()
    )
  );
create policy "turns_insert_own" on interview_turns
  for insert with check (
    session_id in (
      select s.id from interview_sessions s
      join candidates c on c.id = s.candidate_id
      where c.auth_user_id = auth.uid()
    )
  );

-- Results: only for caller's own sessions
create policy "results_select_own" on interview_results
  for select using (
    session_id in (
      select s.id from interview_sessions s
      join candidates c on c.id = s.candidate_id
      where c.auth_user_id = auth.uid()
    )
  );
create policy "results_insert_own" on interview_results
  for insert with check (
    session_id in (
      select s.id from interview_sessions s
      join candidates c on c.id = s.candidate_id
      where c.auth_user_id = auth.uid()
    )
  );

-- Storage bucket for resumes (run once)
insert into storage.buckets (id, name, public) values ('resumes', 'resumes', false)
  on conflict (id) do nothing;

create policy "resume_storage_owner_rw" on storage.objects
  for all using (bucket_id = 'resumes' and owner = auth.uid())
  with check (bucket_id = 'resumes' and owner = auth.uid());
