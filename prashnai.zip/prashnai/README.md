# PrashnAI — AI Voice Interview Platform

An AI-powered mock-interview platform: upload a resume, get a tailored set of
voice questions, answer them aloud, and receive an LLM-scored results report
with a pass/fail verdict, per-question feedback, and an experimental
voice-based confidence signal.

## Stack
- Next.js 14 (App Router) + TypeScript
- Tailwind CSS + minimal shadcn-style primitives (`src/components/ui`)
- Supabase: Postgres (schema in `supabase/schema.sql`), Auth, Storage
- STT: Web Speech API (MVP) — abstracted in `src/hooks/useSpeechToText.ts`
- TTS: Web Speech Synthesis API (MVP) — abstracted in `src/hooks/useTextToSpeech.ts`
- Voice/pitch analysis: Web Audio API (`AnalyserNode` + autocorrelation) — `src/hooks/usePitchAnalysis.ts`
- LLM: Anthropic API (Claude), called only from server-side API routes — `src/lib/anthropic.ts`

## Setup

1. `cp .env.example .env.local` and fill in:
   - `ANTHROPIC_API_KEY`
   - `NEXT_PUBLIC_SUPABASE_URL`, `NEXT_PUBLIC_SUPABASE_ANON_KEY`
   - `SUPABASE_SERVICE_ROLE_KEY` (server-only, keep secret)
2. Create a Supabase project, then run `supabase/schema.sql` in the SQL editor
   (creates tables, RLS policies, and a private `resumes` storage bucket).
3. `npm install`
4. `npm run dev` and open http://localhost:3000

## User flow
`/` (Welcome + mic check) → `/resume` (upload/paste resume) → `/interview/[sessionId]`
(question loop: TTS asks → mic records + live STT + pitch analysis → save turn)
→ `/results/[sessionId]` (calls `/api/interview/finalize`, shows verdict + charts).

## API routes
- `POST /api/resume/analyze` — Claude extracts skills/gaps/role-fit and generates
  6–10 ordered interview questions. Body: `{ resumeText, roleTitle, candidateId }`.
- `POST /api/answer/evaluate` — optional per-answer scoring (0-10), can be
  called live during the interview or skipped in favor of the final pass.
- `POST /api/interview/finalize` — reads all `interview_turns` for a session,
  sends the transcript + voice metrics to Claude, writes `interview_results`,
  marks the session `completed`.

All three keep `ANTHROPIC_API_KEY` server-side only — never sent to the client.

## Provider abstraction points (how to upgrade later)

| Concern | MVP | Swap to production provider by… |
|---|---|---|
| STT | `useSpeechToText` (Web Speech API) | Implementing the same `STTController` shape backed by a route that streams mic audio to Deepgram/AssemblyAI/Whisper and returns transcript chunks over SSE/WebSocket. Call sites (`InterviewRoom`) don't change. |
| TTS | `useTextToSpeech` (speechSynthesis) | Implementing the same `TTSController` shape backed by `/api/tts` that calls ElevenLabs and returns an audio stream, played via an `<audio>` element instead of `speechSynthesis`. |
| Pitch/confidence | `usePitchAnalysis` (client-side Web Audio autocorrelation, heuristic scoring in `src/lib/confidence.ts`) | Weights are documented and tunable in `computeConfidenceScore`. Can be replaced with a more rigorous DSP library or moved server-side without changing the `AudioFeatures` contract other components rely on. |

## Important product notes
- Voice-based "confidence" scoring is an **experimental heuristic** based on
  pitch variance, pause frequency, and volume trend — it is explicitly **not**
  an emotion detector or lie detector, and the UI/prompts say so.
- AI scoring is meant to **support, not replace** human hiring judgment —
  surfaced in the welcome screen and results disclaimer copy.
- Sessions persist via `interview_sessions.status`; a refresh mid-interview
  can resume from Supabase (current MVP re-fetches questions from
  `sessionStorage` — for production, persist/rehydrate the generated question
  list from `candidates.resume_analysis` instead, since `sessionStorage` won't
  survive a device change).
- Recording is capped at 3 minutes/answer (`useAudioRecorder`) and API routes
  have no artificial timeout beyond Next.js/Vercel defaults — set a platform
  timeout appropriate to your Claude call latency in production.
- Auth: the schema assumes `candidates.auth_user_id` ties rows to a Supabase
  Auth user for RLS. This MVP creates candidate rows anonymously for
  simplicity — wire up Supabase Auth (magic link/OAuth) before shipping so
  RLS actually restricts access per-candidate.
- PDF/DOCX resume text extraction is stubbed (plain `.txt` works out of the
  box; PDF/DOCX prompts the user to paste text). Add a server route using
  `pdf-parse`/`mammoth` and Supabase Storage upload for full file support.

## Known gaps / next steps for production
- Wire Supabase Auth end-to-end (currently anonymous inserts).
- Server-side PDF/DOCX parsing + Storage upload for `resume_url`.
- Optional: call `/api/answer/evaluate` live after each turn for immediate
  per-question feedback instead of only at finalize time.
- Add retry/backoff around Claude calls in the API routes.
- Replace `window.print()` PDF export with a proper server-rendered PDF
  (e.g. via `@react-pdf/renderer` or a headless-browser render route).
