import { ResultsDashboard } from "@/components/ResultsDashboard";

export default function ResultsPage({ params }: { params: { sessionId: string } }) {
  return <ResultsDashboard sessionId={params.sessionId} />;
}
