import { NextRequest, NextResponse } from "next/server";
import { callClaudeJSON } from "@/lib/anthropic";
import { createClient } from "@/lib/supabase/server";
import type { ResumeAnalysis } from "@/lib/types";

const SYSTEM_PROMPT = `You are an expert technical recruiter. Given this resume text and target role,
extract: key skills, years of experience, seniority level, notable gaps or red
flags, and a one-paragraph role-fit summary. Then generate 8 interview questions
ordered from warm-up to hardest, covering: (a) technical depth on their strongest
claimed skill, (b) a scenario testing a claimed weakness/gap, (c) behavioral
questions with STAR-format expectations, (d) one unexpected/curveball question
to test adaptability. Return strict JSON: {skills, experience_level, gaps,
role_fit_summary, questions: [{index, text, category, difficulty}]}.
Return ONLY the JSON object, no markdown, no commentary.`;

export async function POST(req: NextRequest) {
  try {
    const { resumeText, roleTitle, candidateId } = await req.json();

    if (!resumeText || typeof resumeText !== "string" || resumeText.trim().length < 20) {
      return NextResponse.json({ error: "resumeText is required and too short." }, { status: 400 });
    }

    const userContent = `Target role: ${roleTitle ?? "Not specified"}\n\nResume text:\n${resumeText}`;

    const analysis = await callClaudeJSON<ResumeAnalysis>(SYSTEM_PROMPT, userContent);

    // Persist to Supabase if a candidateId was provided (RLS enforces ownership).
    if (candidateId) {
      const supabase = createClient();
      const { error } = await supabase
        .from("candidates")
        .update({ resume_text: resumeText, resume_analysis: analysis })
        .eq("id", candidateId);
      if (error) {
        console.error("Failed to persist resume analysis:", error.message);
      }
    }

    return NextResponse.json({ analysis });
  } catch (err: any) {
    console.error("resume/analyze error:", err);
    return NextResponse.json(
      { error: "Failed to analyze resume. Please try again." },
      { status: 500 }
    );
  }
}
