import { NextRequest, NextResponse } from "next/server";
import { callClaudeJSON } from "@/lib/anthropic";
import { createClient } from "@/lib/supabase/server";
import type { InterviewResult, InterviewTurn } from "@/lib/types";

const PASS_THRESHOLD = Number(process.env.INTERVIEW_PASS_THRESHOLD ?? 65);

const SYSTEM_PROMPT = `You are the final interview panel. Given the full transcript (all Q&A pairs),
per-question scores, and voice-confidence metrics (pitch variance, pause
frequency, average volume trend across the session), produce:
- overall_score (0-100, weighted average with harder questions weighted more)
- passed (true/false) against a pass threshold of ${PASS_THRESHOLD}
- 3-5 strengths (specific, evidence-based, cite the question)
- 3-5 weaknesses (specific, evidence-based)
- a concrete improvement_plan (bullet list, actionable, tied to weaknesses)
- confidence_rating (Low/Medium/High) with a 1-2 sentence explanation based on
  the voice metrics (e.g. high pitch variance + frequent long pauses = lower
  confidence; steady pitch + short pauses + strong answers = higher confidence)
Return strict JSON matching this shape:
{overall_score, passed, per_question_scores: [{question_index, score, reasoning}],
strengths: string[], weaknesses: string[], improvement_plan: string,
confidence_rating, confidence_explanation}.
Note: voice-based confidence is a heuristic signal, not a clinical or emotional
assessment — phrase confidence_explanation accordingly (no claims of detecting
emotions, lies, or psychological states).
Return ONLY the JSON object, no markdown, no commentary.`;

export async function POST(req: NextRequest) {
  try {
    const { sessionId } = await req.json();
    if (!sessionId) {
      return NextResponse.json({ error: "sessionId is required." }, { status: 400 });
    }

    const supabase = createClient();

    const { data: turns, error: turnsError } = await supabase
      .from("interview_turns")
      .select("*")
      .eq("session_id", sessionId)
      .order("question_index", { ascending: true });

    if (turnsError) throw turnsError;
    if (!turns || turns.length === 0) {
      return NextResponse.json({ error: "No answered questions found for this session." }, { status: 400 });
    }

    const transcript = (turns as InterviewTurn[])
      .map(
        (t) =>
          `Q${t.question_index}: ${t.question_text}\nAnswer: ${t.answer_text || "(no answer given)"}\nDuration: ${t.duration_seconds}s`
      )
      .join("\n\n");

    const voiceMetrics = (turns as InterviewTurn[])
      .map(
        (t) =>
          `Q${t.question_index}: pitch_variance=${t.pitch_variance}, pause_count=${t.pause_count}, avg_pause_ms=${t.avg_pause_ms}, volume_mean=${t.volume_mean}, confidence_score=${t.confidence_score}`
      )
      .join("\n");

    const userContent = `TRANSCRIPT:\n${transcript}\n\nVOICE METRICS PER QUESTION:\n${voiceMetrics}`;

    const result = await callClaudeJSON<Omit<InterviewResult, "session_id">>(
      SYSTEM_PROMPT,
      userContent
    );

    const fullResult: InterviewResult = { session_id: sessionId, ...result };

    const { error: insertError } = await supabase.from("interview_results").insert({
      session_id: fullResult.session_id,
      overall_score: fullResult.overall_score,
      passed: fullResult.passed,
      per_question_scores: fullResult.per_question_scores,
      strengths: fullResult.strengths,
      weaknesses: fullResult.weaknesses,
      improvement_plan: fullResult.improvement_plan,
      confidence_rating: fullResult.confidence_rating,
      confidence_explanation: fullResult.confidence_explanation,
    });
    if (insertError) throw insertError;

    await supabase
      .from("interview_sessions")
      .update({ status: "completed", completed_at: new Date().toISOString() })
      .eq("id", sessionId);

    return NextResponse.json({ result: fullResult });
  } catch (err: any) {
    console.error("interview/finalize error:", err);
    return NextResponse.json(
      { error: "Failed to finalize interview scoring. Please try again." },
      { status: 500 }
    );
  }
}
