import { NextRequest, NextResponse } from "next/server";
import { callClaudeJSON } from "@/lib/anthropic";

const SYSTEM_PROMPT = `You are grading one interview answer. Given the question, the candidate's
transcribed answer, and their resume context, score 0-10 on: relevance,
depth/specificity, correctness, and communication clarity. Give 1-2 sentences
of reasoning. Return strict JSON: {score, reasoning}.
Return ONLY the JSON object, no markdown, no commentary.`;

interface EvaluateRequest {
  question: string;
  answer: string;
  resumeContext?: string;
}

export async function POST(req: NextRequest) {
  try {
    const { question, answer, resumeContext }: EvaluateRequest = await req.json();

    if (!question || !answer) {
      return NextResponse.json({ error: "question and answer are required." }, { status: 400 });
    }

    // Graceful handling of empty/near-empty answers without burning an LLM call.
    if (answer.trim().length < 3) {
      return NextResponse.json({
        score: 0,
        reasoning: "No substantive answer was given (silence or no response detected).",
      });
    }

    const userContent = `Question: ${question}\n\nCandidate answer: ${answer}\n\nResume context: ${
      resumeContext ?? "Not provided"
    }`;

    const result = await callClaudeJSON<{ score: number; reasoning: string }>(
      SYSTEM_PROMPT,
      userContent
    );

    return NextResponse.json(result);
  } catch (err: any) {
    console.error("answer/evaluate error:", err);
    return NextResponse.json({ error: "Failed to evaluate answer." }, { status: 500 });
  }
}
