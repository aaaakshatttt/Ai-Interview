import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "PrashnAI — AI Voice Interview Practice",
  description: "Practice technical and behavioral interviews with an AI voice interviewer.",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className="dark">
      <body className="min-h-screen antialiased">{children}</body>
    </html>
  );
}
