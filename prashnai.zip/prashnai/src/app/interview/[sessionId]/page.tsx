import { InterviewRoom } from "@/components/InterviewRoom";

export default function InterviewPage({ params }: { params: { sessionId: string } }) {
  return <InterviewRoom sessionId={params.sessionId} />;
}
