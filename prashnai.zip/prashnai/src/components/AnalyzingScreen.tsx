export function AnalyzingScreen({ label = "Scoring your interview…" }: { label?: string }) {
  return (
    <div className="mx-auto flex max-w-md flex-col items-center justify-center gap-4 px-4 py-32 text-center">
      <div className="h-10 w-10 animate-spin rounded-full border-2 border-primary border-t-transparent" />
      <p className="text-muted-foreground">{label}</p>
      <p className="text-xs text-muted-foreground">This usually takes 10–20 seconds.</p>
    </div>
  );
}
