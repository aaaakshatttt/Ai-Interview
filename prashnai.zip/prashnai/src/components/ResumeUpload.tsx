"use client";
import { useCallback, useState } from "react";
import { useRouter } from "next/navigation";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { createClient } from "@/lib/supabase/client";

/**
 * NOTE: robust PDF/DOCX text extraction belongs server-side (pdf-parse /
 * mammoth). This MVP does a best-effort client-side read for .txt and falls
 * back to asking the user to paste text for PDF/DOCX until that server route
 * is wired up — see README "Provider abstraction points".
 */
async function extractResumeText(file: File): Promise<string> {
  if (file.type === "text/plain") {
    return await file.text();
  }
  throw new Error("UNSUPPORTED_CLIENT_EXTRACTION");
}

export function ResumeUpload() {
  const router = useRouter();
  const [dragOver, setDragOver] = useState(false);
  const [fileName, setFileName] = useState<string | null>(null);
  const [pastedText, setPastedText] = useState("");
  const [roleTitle, setRoleTitle] = useState("");
  const [status, setStatus] = useState<"idle" | "uploading" | "analyzing" | "error">("idle");
  const [error, setError] = useState<string | null>(null);

  const handleFile = useCallback(async (file: File) => {
    setFileName(file.name);
    setError(null);
    try {
      const text = await extractResumeText(file);
      setPastedText(text);
    } catch {
      setError(
        "We couldn't auto-extract text from this file type yet. Please paste your resume text below."
      );
    }
  }, []);

  const onDrop = useCallback(
    (e: React.DragEvent) => {
      e.preventDefault();
      setDragOver(false);
      const file = e.dataTransfer.files?.[0];
      if (file) handleFile(file);
    },
    [handleFile]
  );

  const startInterview = useCallback(async () => {
    if (pastedText.trim().length < 20) {
      setError("Please provide resume text (at least a few sentences) before continuing.");
      return;
    }
    setStatus("analyzing");
    setError(null);
    try {
      const supabase = createClient();

      // Create (or reuse) a candidate row. Anonymous for MVP — see README re: auth.
      const { data: candidate, error: candidateErr } = await supabase
        .from("candidates")
        .insert({ resume_text: pastedText })
        .select()
        .single();
      if (candidateErr) throw candidateErr;

      const res = await fetch("/api/resume/analyze", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ resumeText: pastedText, roleTitle, candidateId: candidate.id }),
      });
      if (!res.ok) {
        const body = await res.json().catch(() => ({}));
        throw new Error(body.error || "Resume analysis failed.");
      }
      const { analysis } = await res.json();

      const { data: session, error: sessionErr } = await supabase
        .from("interview_sessions")
        .insert({ candidate_id: candidate.id, role_title: roleTitle, status: "in_progress" })
        .select()
        .single();
      if (sessionErr) throw sessionErr;

      sessionStorage.setItem(`prashnai:questions:${session.id}`, JSON.stringify(analysis.questions));
      router.push(`/interview/${session.id}`);
    } catch (e: any) {
      console.error(e);
      setError(e.message || "Something went wrong. Please try again.");
      setStatus("error");
    }
  }, [pastedText, roleTitle, router]);

  return (
    <div className="mx-auto max-w-2xl px-4 py-16">
      <h1 className="text-2xl font-bold">Upload your resume</h1>
      <p className="mt-1 text-sm text-muted-foreground">
        We&apos;ll analyze it to tailor your interview questions.
      </p>

      <Card className="mt-6 space-y-4">
        <input
          placeholder="Target role (e.g. Senior Frontend Engineer)"
          className="w-full rounded-md border border-border bg-transparent px-3 py-2 text-sm"
          value={roleTitle}
          onChange={(e) => setRoleTitle(e.target.value)}
        />

        <div
          onDragOver={(e) => {
            e.preventDefault();
            setDragOver(true);
          }}
          onDragLeave={() => setDragOver(false)}
          onDrop={onDrop}
          className={`rounded-lg border-2 border-dashed p-8 text-center text-sm transition-colors ${
            dragOver ? "border-primary bg-primary/5" : "border-border"
          }`}
        >
          <p>Drag & drop your resume (.txt for auto-extract; PDF/DOCX: paste text below)</p>
          <input
            type="file"
            accept=".txt,.pdf,.doc,.docx"
            className="mt-3 text-xs"
            onChange={(e) => e.target.files?.[0] && handleFile(e.target.files[0])}
          />
          {fileName && <p className="mt-2 text-xs text-muted-foreground">Selected: {fileName}</p>}
        </div>

        <textarea
          placeholder="Paste resume text here…"
          className="h-48 w-full resize-none rounded-md border border-border bg-transparent px-3 py-2 text-sm"
          value={pastedText}
          onChange={(e) => setPastedText(e.target.value)}
        />

        {error && <p className="text-sm text-destructive">{error}</p>}

        <Button size="lg" onClick={startInterview} disabled={status === "analyzing"}>
          {status === "analyzing" ? "Analyzing resume & generating questions…" : "Analyze & start interview →"}
        </Button>
      </Card>
    </div>
  );
}
