"use client";
import { useRouter } from "next/navigation";
import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { MicPermissionGate } from "@/components/MicPermissionGate";

export function WelcomeScreen() {
  const router = useRouter();
  const [micOk, setMicOk] = useState(false);

  return (
    <div className="mx-auto max-w-2xl px-4 py-16">
      <h1 className="text-3xl font-bold tracking-tight">PrashnAI</h1>
      <p className="mt-2 text-muted-foreground">AI-powered voice interview practice</p>

      <Card className="mt-8 space-y-4">
        <h2 className="text-xl font-semibold">How it works</h2>
        <ol className="list-decimal space-y-2 pl-5 text-sm text-muted-foreground">
          <li>Upload your resume — we&apos;ll tailor the interview to your background.</li>
          <li>Answer 6–10 spoken questions, from warm-up to curveball.</li>
          <li>Get a scored results report with strengths, gaps, and an improvement plan.</li>
        </ol>

        <div className="rounded-md border border-border bg-muted/30 p-3 text-xs text-muted-foreground">
          This is an AI-scored practice tool meant to support, not replace, human judgment.
          Voice-based &quot;confidence&quot; scoring is an experimental heuristic — it estimates
          speaking patterns (pitch, pace, pauses), not emotions or truthfulness.
        </div>

        {!micOk ? (
          <MicPermissionGate onGranted={() => setMicOk(true)} />
        ) : (
          <Button size="lg" onClick={() => router.push("/resume")}>
            Continue to resume upload →
          </Button>
        )}
      </Card>
    </div>
  );
}
