"use client";
import { useEffect, useState } from "react";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { AnalyzingScreen } from "@/components/AnalyzingScreen";
import { createClient } from "@/lib/supabase/client";
import type { InterviewResult, InterviewTurn } from "@/lib/types";

interface Props {
  sessionId: string;
}

export function ResultsDashboard({ sessionId }: Props) {
  const [result, setResult] = useState<InterviewResult | null>(null);
  const [turns, setTurns] = useState<InterviewTurn[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;
    async function run() {
      const supabase = createClient();
      const { data: existing } = await supabase
        .from("interview_results")
        .select("*")
        .eq("session_id", sessionId)
        .maybeSingle();

      const { data: turnRows } = await supabase
        .from("interview_turns")
        .select("*")
        .eq("session_id", sessionId)
        .order("question_index", { ascending: true });
      if (!cancelled && turnRows) setTurns(turnRows as InterviewTurn[]);

      if (existing) {
        if (!cancelled) {
          setResult(existing as unknown as InterviewResult);
          setLoading(false);
        }
        return;
      }

      try {
        const res = await fetch("/api/interview/finalize", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ sessionId }),
        });
        if (!res.ok) {
          const body = await res.json().catch(() => ({}));
          throw new Error(body.error || "Failed to score interview.");
        }
        const { result: finalized } = await res.json();
        if (!cancelled) setResult(finalized);
      } catch (e: any) {
        if (!cancelled) setError(e.message || "Something went wrong while scoring your interview.");
      } finally {
        if (!cancelled) setLoading(false);
      }
    }
    run();
    return () => {
      cancelled = true;
    };
  }, [sessionId]);

  if (loading) return <AnalyzingScreen />;

  if (error || !result) {
    return (
      <div className="mx-auto max-w-xl px-4 py-16">
        <Card>
          <p className="text-destructive">{error || "No results available."}</p>
        </Card>
      </div>
    );
  }

  const chartData = turns.map((t) => ({ name: `Q${t.question_index}`, confidence: t.confidence_score }));

  return (
    <div className="mx-auto max-w-3xl space-y-6 px-4 py-12">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">Your results</h1>
          <p className="text-sm text-muted-foreground">
            AI-scored practice interview — meant to support, not replace, human judgment.
          </p>
        </div>
        <span
          className={`rounded-full px-4 py-1.5 text-sm font-semibold ${
            result.passed ? "bg-green-500/15 text-green-400" : "bg-destructive/15 text-destructive"
          }`}
        >
          {result.passed ? "PASS" : "NEEDS WORK"}
        </span>
      </div>

      <Card className="flex items-center justify-between">
        <div>
          <p className="text-sm text-muted-foreground">Overall score</p>
          <p className="text-4xl font-bold">{result.overall_score}/100</p>
        </div>
        <div className="text-right">
          <p className="text-sm text-muted-foreground">Voice confidence (experimental)</p>
          <p className="text-xl font-semibold">{result.confidence_rating}</p>
        </div>
      </Card>

      <Card>
        <h2 className="mb-2 font-semibold">Per-question scores</h2>
        <div className="space-y-3">
          {result.per_question_scores.map((pq) => (
            <div key={pq.question_index} className="border-b border-border pb-2 last:border-0">
              <div className="flex justify-between text-sm font-medium">
                <span>Question {pq.question_index}</span>
                <span>{pq.score}/10</span>
              </div>
              <p className="text-sm text-muted-foreground">{pq.reasoning}</p>
            </div>
          ))}
        </div>
      </Card>

      {chartData.length > 0 && (
        <Card>
          <h2 className="mb-2 font-semibold">Confidence signal by question</h2>
          <p className="mb-2 text-xs text-muted-foreground">
            Derived from speaking pace, pauses, pitch and volume — not a clinical or emotional assessment.
          </p>
          <div className="h-56">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                <XAxis dataKey="name" stroke="hsl(var(--muted-foreground))" fontSize={12} />
                <YAxis domain={[0, 100]} stroke="hsl(var(--muted-foreground))" fontSize={12} />
                <Tooltip contentStyle={{ background: "hsl(var(--card))", border: "1px solid hsl(var(--border))" }} />
                <Bar dataKey="confidence" fill="hsl(var(--primary))" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
          <p className="mt-2 text-xs text-muted-foreground">{result.confidence_explanation}</p>
        </Card>
      )}

      <div className="grid gap-4 sm:grid-cols-2">
        <Card>
          <h2 className="mb-2 font-semibold text-green-400">Strengths</h2>
          <ul className="list-disc space-y-1 pl-5 text-sm text-muted-foreground">
            {result.strengths.map((s, i) => (
              <li key={i}>{s}</li>
            ))}
          </ul>
        </Card>
        <Card>
          <h2 className="mb-2 font-semibold text-destructive">Weaknesses</h2>
          <ul className="list-disc space-y-1 pl-5 text-sm text-muted-foreground">
            {result.weaknesses.map((s, i) => (
              <li key={i}>{s}</li>
            ))}
          </ul>
        </Card>
      </div>

      <Card>
        <h2 className="mb-2 font-semibold">Improvement plan</h2>
        <p className="whitespace-pre-line text-sm text-muted-foreground">{result.improvement_plan}</p>
      </Card>

      <div className="flex gap-3">
        <Button onClick={() => window.print()}>Download / print as PDF</Button>
      </div>
    </div>
  );
}
