"use client";
import { useCallback, useEffect, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useTextToSpeech } from "@/hooks/useTextToSpeech";
import { useSpeechToText } from "@/hooks/useSpeechToText";
import { usePitchAnalysis } from "@/hooks/usePitchAnalysis";
import { useAudioRecorder } from "@/hooks/useAudioRecorder";
import { createClient } from "@/lib/supabase/client";
import type { InterviewQuestion } from "@/lib/types";

interface Props {
  sessionId: string;
}

type Phase = "loading" | "question" | "recording" | "saving" | "done";

export function InterviewRoom({ sessionId }: Props) {
  const router = useRouter();
  const [questions, setQuestions] = useState<InterviewQuestion[]>([]);
  const [index, setIndex] = useState(0);
  const [phase, setPhase] = useState<Phase>("loading");
  const [error, setError] = useState<string | null>(null);
  const recordStartRef = useRef<number>(0);

  const tts = useTextToSpeech();
  const stt = useSpeechToText();
  const pitch = usePitchAnalysis();

  const handleMaxDuration = useCallback(() => {
    if (phase === "recording") stopRecording();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [phase]);
  const recorder = useAudioRecorder(handleMaxDuration);

  useEffect(() => {
    const raw = sessionStorage.getItem(`prashnai:questions:${sessionId}`);
    if (!raw) {
      setError("No questions found for this session. Please start over from the resume upload step.");
      return;
    }
    const parsed: InterviewQuestion[] = JSON.parse(raw);
    setQuestions(parsed);
    setPhase("question");
  }, [sessionId]);

  const askQuestion = useCallback(() => {
    const q = questions[index];
    if (!q) return;
    tts.speak(q.text);
  }, [questions, index, tts]);

  useEffect(() => {
    if (phase === "question" && questions.length > 0) askQuestion();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [phase, index, questions]);

  const startRecording = useCallback(async () => {
    tts.cancel();
    stt.reset();
    setError(null);
    const stream = await recorder.start();
    if (!stream) {
      setError(recorder.error || "Microphone unavailable.");
      return;
    }
    pitch.start(stream);
    stt.start();
    recordStartRef.current = Date.now();
    setPhase("recording");
  }, [recorder, pitch, stt, tts]);

  const stopRecording = useCallback(async () => {
    stt.stop();
    const features = pitch.stop();
    await recorder.stop();
    const durationSeconds = (Date.now() - recordStartRef.current) / 1000;
    setPhase("saving");

    const q = questions[index];
    try {
      const supabase = createClient();
      await supabase.from("interview_turns").insert({
        session_id: sessionId,
        question_index: q.index,
        question_text: q.text,
        answer_text: stt.transcript || "",
        duration_seconds: Math.round(durationSeconds),
        pitch_mean: features.pitch_mean,
        pitch_variance: features.pitch_variance,
        pause_count: features.pause_count,
        avg_pause_ms: features.avg_pause_ms,
        volume_mean: features.volume_mean,
        confidence_score: features.confidence_score,
      });
    } catch (e) {
      console.error("Failed to save turn:", e);
      // Non-fatal: continue the interview so the candidate isn't blocked.
    }

    if (index + 1 < questions.length) {
      setTimeout(() => {
        setIndex((i) => i + 1);
        setPhase("question");
      }, 800);
    } else {
      setPhase("done");
      const supabase = createClient();
      await supabase
        .from("interview_sessions")
        .update({ status: "completed", completed_at: new Date().toISOString() })
        .eq("id", sessionId);
      router.push(`/results/${sessionId}`);
    }
  }, [stt, pitch, recorder, questions, index, sessionId, router]);

  const skipQuestion = useCallback(() => {
    if (index + 1 < questions.length) {
      setIndex((i) => i + 1);
      setPhase("question");
    } else {
      router.push(`/results/${sessionId}`);
    }
  }, [index, questions.length, router, sessionId]);

  if (error) {
    return (
      <div className="mx-auto max-w-xl px-4 py-16">
        <Card>
          <p className="text-destructive">{error}</p>
          <Button className="mt-4" onClick={() => router.push("/resume")}>
            Back to resume upload
          </Button>
        </Card>
      </div>
    );
  }

  if (phase === "loading" || questions.length === 0) {
    return <div className="px-4 py-16 text-center text-muted-foreground">Loading your interview…</div>;
  }

  const q = questions[index];

  return (
    <div className="mx-auto max-w-2xl px-4 py-12">
      <div className="mb-4 flex items-center justify-between text-sm text-muted-foreground">
        <span>
          Question {index + 1} of {questions.length}
        </span>
        <span className="capitalize">
          {q.category} · {q.difficulty}
        </span>
      </div>

      <Card className="space-y-6">
        <p className="text-lg font-medium leading-relaxed">{q.text}</p>

        {tts.isSpeaking && <p className="text-sm text-primary">🔊 Speaking question…</p>}

        {phase === "recording" && (
          <div className="space-y-2 rounded-md border border-border bg-muted/30 p-3">
            <p className="flex items-center gap-2 text-sm">
              <span className="h-2 w-2 animate-pulse rounded-full bg-destructive" /> Recording…
            </p>
            {stt.isSupported ? (
              <p className="text-sm text-muted-foreground">
                {stt.transcript} <span className="opacity-60">{stt.interimTranscript}</span>
              </p>
            ) : (
              <p className="text-xs text-destructive">
                Live transcription isn&apos;t supported in this browser. Your answer will be saved without a transcript.
              </p>
            )}
          </div>
        )}

        {phase === "saving" && <p className="text-sm text-muted-foreground">Analyzing your answer…</p>}

        <div className="flex flex-wrap gap-3">
          {phase === "question" && (
            <Button onClick={startRecording} disabled={tts.isSpeaking}>
              🎙️ Start answering
            </Button>
          )}
          {phase === "recording" && (
            <Button variant="destructive" onClick={stopRecording}>
              ⏹ Stop & submit answer
            </Button>
          )}
          {(phase === "question" || phase === "recording") && (
            <Button variant="outline" onClick={skipQuestion}>
              Skip question
            </Button>
          )}
        </div>

        {recorder.error && <p className="text-sm text-destructive">{recorder.error}</p>}
      </Card>
    </div>
  );
}
