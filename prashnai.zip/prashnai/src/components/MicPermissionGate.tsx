"use client";
import { useCallback, useState } from "react";
import { Button } from "@/components/ui/button";

interface Props {
  onGranted: () => void;
}

/**
 * Checks/requests mic permission before letting the candidate proceed.
 * Handles denial gracefully with a retry affordance and instructions.
 */
export function MicPermissionGate({ onGranted }: Props) {
  const [status, setStatus] = useState<"idle" | "checking" | "denied" | "error">("idle");

  const requestAccess = useCallback(async () => {
    setStatus("checking");
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      stream.getTracks().forEach((t) => t.stop());
      onGranted();
    } catch (e: any) {
      setStatus(e?.name === "NotAllowedError" ? "denied" : "error");
    }
  }, [onGranted]);

  return (
    <div className="space-y-3">
      <Button onClick={requestAccess} disabled={status === "checking"}>
        {status === "checking" ? "Requesting mic access…" : "Allow microphone access"}
      </Button>
      {status === "denied" && (
        <p className="text-sm text-destructive">
          Microphone access was denied. Please enable it in your browser&apos;s site settings and try again.
        </p>
      )}
      {status === "error" && (
        <p className="text-sm text-destructive">
          Couldn&apos;t access your microphone. Check that a mic is connected and try again.
        </p>
      )}
    </div>
  );
}
