"use client";
import { useCallback, useEffect, useRef, useState } from "react";

/**
 * STT provider abstraction. MVP implementation wraps the browser's Web
 * Speech API (SpeechRecognition). To swap in Deepgram/AssemblyAI/Whisper:
 * implement the same STTController interface (start/stop/reset + the same
 * returned state shape) backed by a server route that streams audio to the
 * provider, and swap this hook's internals — call sites don't change.
 */
export interface STTController {
  isSupported: boolean;
  isListening: boolean;
  transcript: string;
  interimTranscript: string;
  error: string | null;
  start: () => void;
  stop: () => void;
  reset: () => void;
}

export function useSpeechToText(): STTController {
  const [isListening, setIsListening] = useState(false);
  const [transcript, setTranscript] = useState("");
  const [interimTranscript, setInterimTranscript] = useState("");
  const [error, setError] = useState<string | null>(null);
  const recognitionRef = useRef<any>(null);
  const isSupported =
    typeof window !== "undefined" &&
    !!((window as any).SpeechRecognition || (window as any).webkitSpeechRecognition);

  useEffect(() => {
    if (!isSupported) return;
    const SpeechRecognition =
      (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    const recognition = new SpeechRecognition();
    recognition.continuous = true;
    recognition.interimResults = true;
    recognition.lang = "en-US";

    recognition.onresult = (event: any) => {
      let finalChunk = "";
      let interimChunk = "";
      for (let i = event.resultIndex; i < event.results.length; i++) {
        const res = event.results[i];
        if (res.isFinal) finalChunk += res[0].transcript;
        else interimChunk += res[0].transcript;
      }
      if (finalChunk) setTranscript((prev) => (prev + " " + finalChunk).trim());
      setInterimTranscript(interimChunk);
    };

    recognition.onerror = (event: any) => {
      // "no-speech" fires often on silence; don't treat as fatal.
      if (event.error !== "no-speech") setError(event.error);
    };

    recognition.onend = () => {
      // Some mobile browsers auto-stop after a pause; restart if still "listening".
      if (isListening) {
        try {
          recognition.start();
        } catch {}
      }
    };

    recognitionRef.current = recognition;
    return () => {
      try {
        recognition.stop();
      } catch {}
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isSupported]);

  const start = useCallback(() => {
    setError(null);
    if (!isSupported || !recognitionRef.current) {
      setError("Speech recognition is not supported in this browser.");
      return;
    }
    try {
      recognitionRef.current.start();
      setIsListening(true);
    } catch (e) {
      // start() throws if already started — ignore.
    }
  }, [isSupported]);

  const stop = useCallback(() => {
    setIsListening(false);
    try {
      recognitionRef.current?.stop();
    } catch {}
  }, []);

  const reset = useCallback(() => {
    setTranscript("");
    setInterimTranscript("");
    setError(null);
  }, []);

  return { isSupported, isListening, transcript, interimTranscript, error, start, stop, reset };
}
