"use client";
import { useCallback, useRef, useState } from "react";
import { computeConfidenceScore } from "@/lib/confidence";
import type { AudioFeatures } from "@/lib/types";

const SAMPLE_RATE_HZ = 10; // ~10Hz sampling per spec
const SILENCE_RMS_THRESHOLD = 0.02;
const PAUSE_MIN_MS = 700;

/**
 * Runs a Web Audio AnalyserNode over a MediaStream and samples pitch (via
 * autocorrelation), volume (RMS), and pause gaps at ~10Hz while recording.
 * Returns aggregated AudioFeatures when stopped.
 */
export function usePitchAnalysis() {
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const audioCtxRef = useRef<AudioContext | null>(null);
  const analyserRef = useRef<AnalyserNode | null>(null);
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const sourceRef = useRef<MediaStreamAudioSourceNode | null>(null);

  const samplesRef = useRef<{ pitch: number; volume: number; t: number }[]>([]);
  const silenceStartRef = useRef<number | null>(null);
  const pausesRef = useRef<number[]>([]);
  const startTimeRef = useRef<number>(0);

  const start = useCallback((stream: MediaStream) => {
    samplesRef.current = [];
    pausesRef.current = [];
    silenceStartRef.current = null;
    startTimeRef.current = Date.now();

    const AudioContextCtor = window.AudioContext || (window as any).webkitAudioContext;
    const audioCtx = new AudioContextCtor();
    const source = audioCtx.createMediaStreamSource(stream);
    const analyser = audioCtx.createAnalyser();
    analyser.fftSize = 2048;
    source.connect(analyser);

    audioCtxRef.current = audioCtx;
    analyserRef.current = analyser;
    sourceRef.current = source;

    const buffer = new Float32Array(analyser.fftSize);

    intervalRef.current = setInterval(() => {
      analyser.getFloatTimeDomainData(buffer);
      const rms = computeRMS(buffer);
      const pitch = estimatePitchAutocorrelation(buffer, audioCtx.sampleRate);
      const now = Date.now();
      samplesRef.current.push({ pitch, volume: rms, t: now });

      if (rms < SILENCE_RMS_THRESHOLD) {
        if (silenceStartRef.current === null) silenceStartRef.current = now;
      } else {
        if (silenceStartRef.current !== null) {
          const gap = now - silenceStartRef.current;
          if (gap >= PAUSE_MIN_MS) pausesRef.current.push(gap);
          silenceStartRef.current = null;
        }
      }
    }, 1000 / SAMPLE_RATE_HZ);

    setIsAnalyzing(true);
  }, []);

  const stop = useCallback((): AudioFeatures => {
    if (intervalRef.current) clearInterval(intervalRef.current);
    sourceRef.current?.disconnect();
    audioCtxRef.current?.close().catch(() => {});
    setIsAnalyzing(false);

    const samples = samplesRef.current.filter((s) => s.pitch > 0);
    const pitches = samples.map((s) => s.pitch);
    const volumes = samplesRef.current.map((s) => s.volume);

    const pitchMean = mean(pitches);
    const pitchVariance = variance(pitches, pitchMean);
    const volumeMean = mean(volumes);
    const volumeTrendSlope = linearTrendSlope(volumes);
    const pauseCount = pausesRef.current.length;
    const avgPauseMs = pausesRef.current.length
      ? mean(pausesRef.current)
      : 0;
    const durationSeconds = (Date.now() - startTimeRef.current) / 1000;

    const confidence_score = computeConfidenceScore({
      pitchMean,
      pitchVariance,
      pauseCount,
      avgPauseMs,
      volumeMean,
      volumeTrendSlope,
      durationSeconds,
    });

    return {
      pitch_mean: round2(pitchMean),
      pitch_variance: round2(pitchVariance),
      pause_count: pauseCount,
      avg_pause_ms: round2(avgPauseMs),
      volume_mean: round2(volumeMean),
      confidence_score,
    };
  }, []);

  return { isAnalyzing, start, stop };
}

function computeRMS(buf: Float32Array): number {
  let sum = 0;
  for (let i = 0; i < buf.length; i++) sum += buf[i] * buf[i];
  return Math.sqrt(sum / buf.length);
}

// Basic autocorrelation-based pitch (F0) estimator. Returns 0 if no
// confident pitch found (silence/unvoiced).
function estimatePitchAutocorrelation(buf: Float32Array, sampleRate: number): number {
  const SIZE = buf.length;
  const rms = computeRMS(buf);
  if (rms < SILENCE_RMS_THRESHOLD) return 0;

  let r1 = 0,
    r2 = SIZE - 1;
  const threshold = 0.2;
  for (let i = 0; i < SIZE / 2; i++) {
    if (Math.abs(buf[i]) < threshold) {
      r1 = i;
      break;
    }
  }
  for (let i = 1; i < SIZE / 2; i++) {
    if (Math.abs(buf[SIZE - i]) < threshold) {
      r2 = SIZE - i;
      break;
    }
  }
  const trimmed = buf.slice(r1, r2);
  const n = trimmed.length;
  const c = new Array(n).fill(0);
  for (let lag = 0; lag < n; lag++) {
    let sum = 0;
    for (let i = 0; i < n - lag; i++) sum += trimmed[i] * trimmed[i + lag];
    c[lag] = sum;
  }
  let d = 0;
  while (d < n - 1 && c[d] > c[d + 1]) d++;
  let maxVal = -1,
    maxPos = -1;
  for (let i = d; i < n; i++) {
    if (c[i] > maxVal) {
      maxVal = c[i];
      maxPos = i;
    }
  }
  if (maxPos <= 0) return 0;
  const freq = sampleRate / maxPos;
  // Human voice fundamental range guard
  if (freq < 60 || freq > 500) return 0;
  return freq;
}

function mean(arr: number[]): number {
  if (!arr.length) return 0;
  return arr.reduce((a, b) => a + b, 0) / arr.length;
}
function variance(arr: number[], m: number): number {
  if (!arr.length) return 0;
  return arr.reduce((a, b) => a + (b - m) ** 2, 0) / arr.length;
}
function linearTrendSlope(arr: number[]): number {
  const n = arr.length;
  if (n < 2) return 0;
  const xMean = (n - 1) / 2;
  const yMean = mean(arr);
  let num = 0,
    den = 0;
  for (let i = 0; i < n; i++) {
    num += (i - xMean) * (arr[i] - yMean);
    den += (i - xMean) ** 2;
  }
  return den === 0 ? 0 : num / den;
}
function round2(n: number): number {
  return Math.round(n * 100) / 100;
}
