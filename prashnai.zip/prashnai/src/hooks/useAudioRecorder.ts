"use client";
import { useCallback, useRef, useState } from "react";

const MAX_RECORDING_MS = 3 * 60 * 1000; // 3 min/answer hard cap

export interface AudioRecorderController {
  isRecording: boolean;
  error: string | null;
  start: () => Promise<MediaStream | null>;
  stop: () => Promise<Blob | null>;
}

/**
 * Wraps getUserMedia + MediaRecorder. Returns the raw MediaStream on start
 * so callers (STT + pitch analysis hooks) can attach to the same stream,
 * and returns a recorded audio Blob on stop for optional Storage upload.
 */
export function useAudioRecorder(onMaxDurationReached?: () => void): AudioRecorderController {
  const [isRecording, setIsRecording] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const chunksRef = useRef<Blob[]>([]);
  const streamRef = useRef<MediaStream | null>(null);
  const timeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  const start = useCallback(async (): Promise<MediaStream | null> => {
    setError(null);
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      streamRef.current = stream;
      chunksRef.current = [];
      const recorder = new MediaRecorder(stream);
      recorder.ondataavailable = (e) => {
        if (e.data.size > 0) chunksRef.current.push(e.data);
      };
      mediaRecorderRef.current = recorder;
      recorder.start();
      setIsRecording(true);

      timeoutRef.current = setTimeout(() => {
        onMaxDurationReached?.();
      }, MAX_RECORDING_MS);

      return stream;
    } catch (e: any) {
      setError(
        e?.name === "NotAllowedError"
          ? "Microphone permission was denied."
          : "Could not access the microphone."
      );
      return null;
    }
  }, [onMaxDurationReached]);

  const stop = useCallback((): Promise<Blob | null> => {
    return new Promise((resolve) => {
      if (timeoutRef.current) clearTimeout(timeoutRef.current);
      const recorder = mediaRecorderRef.current;
      if (!recorder || recorder.state === "inactive") {
        setIsRecording(false);
        resolve(null);
        return;
      }
      recorder.onstop = () => {
        const blob = new Blob(chunksRef.current, { type: "audio/webm" });
        streamRef.current?.getTracks().forEach((t) => t.stop());
        setIsRecording(false);
        resolve(blob);
      };
      recorder.stop();
    });
  }, []);

  return { isRecording, error, start, stop };
}
