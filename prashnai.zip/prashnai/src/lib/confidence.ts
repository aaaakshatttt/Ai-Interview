import type { AudioFeatures } from "./types";

/**
 * Client-side heuristic confidence score (0-100) from raw voice metrics.
 * IMPORTANT: this is a tunable heuristic, not a validated psychological or
 * emotion-detection model. It should be presented to users as experimental.
 *
 * Weights (documented, tunable):
 *  - Pitch stability (lower variance -> higher score): 30%
 *  - Pause behavior (fewer/shorter pauses -> higher score): 30%
 *  - Volume steadiness (avoid trailing-off): 25%
 *  - Speaking duration sanity (very short answers penalized): 15%
 */
export function computeConfidenceScore(input: {
  pitchMean: number;
  pitchVariance: number;
  pauseCount: number;
  avgPauseMs: number;
  volumeMean: number;
  volumeTrendSlope: number; // negative = trailing off
  durationSeconds: number;
}): number {
  const {
    pitchVariance,
    pauseCount,
    avgPauseMs,
    volumeMean,
    volumeTrendSlope,
    durationSeconds,
  } = input;

  // Normalize pitch variance: assume 0-2500 Hz^2 typical range for speech.
  const pitchScore = clamp01(1 - pitchVariance / 2500) * 30;

  // Pause penalty: more pauses / longer average pause -> lower score.
  const pauseRate = durationSeconds > 0 ? pauseCount / (durationSeconds / 10) : 0;
  const pauseScore = clamp01(1 - (pauseRate * 0.4 + avgPauseMs / 3000)) * 30;

  // Volume steadiness: penalize low volume and strong negative trend (trailing off).
  const volumeLevelScore = clamp01(volumeMean / 0.6) * 0.6;
  const volumeTrendScore = clamp01(1 - Math.max(0, -volumeTrendSlope) * 5) * 0.4;
  const volumeScore = (volumeLevelScore + volumeTrendScore) * 25;

  // Duration sanity: very short answers (<5s) are penalized as likely low-effort.
  const durationScore = clamp01(durationSeconds / 15) * 15;

  const total = pitchScore + pauseScore + volumeScore + durationScore;
  return Math.round(clamp01(total / 100) * 100);
}

function clamp01(n: number): number {
  if (Number.isNaN(n)) return 0;
  return Math.max(0, Math.min(1, n));
}

export function sessionConfidenceRating(turns: AudioFeatures[]): "Low" | "Medium" | "High" {
  if (turns.length === 0) return "Medium";
  const avg = turns.reduce((s, t) => s + t.confidence_score, 0) / turns.length;
  if (avg >= 70) return "High";
  if (avg >= 45) return "Medium";
  return "Low";
}
