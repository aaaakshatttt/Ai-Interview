export type Difficulty = "easy" | "medium" | "hard";

export interface InterviewQuestion {
  index: number;
  text: string;
  category: "technical" | "gap" | "behavioral" | "curveball";
  difficulty: Difficulty;
}

export interface ResumeAnalysis {
  skills: string[];
  experience_level: string;
  gaps: string[];
  role_fit_summary: string;
  questions: InterviewQuestion[];
}

export interface AudioFeatures {
  pitch_mean: number;
  pitch_variance: number;
  pause_count: number;
  avg_pause_ms: number;
  volume_mean: number;
  confidence_score: number; // 0-100 heuristic, computed client-side
}

export interface InterviewTurn {
  id?: string;
  session_id: string;
  question_index: number;
  question_text: string;
  answer_text: string;
  answer_audio_url?: string | null;
  duration_seconds: number;
  pitch_mean: number;
  pitch_variance: number;
  pause_count: number;
  avg_pause_ms: number;
  volume_mean: number;
  confidence_score: number;
}

export interface PerQuestionScore {
  question_index: number;
  score: number; // 0-10
  reasoning: string;
}

export interface InterviewResult {
  session_id: string;
  overall_score: number; // 0-100
  passed: boolean;
  per_question_scores: PerQuestionScore[];
  strengths: string[];
  weaknesses: string[];
  improvement_plan: string;
  confidence_rating: "Low" | "Medium" | "High";
  confidence_explanation: string;
}
