import Anthropic from "@anthropic-ai/sdk";

// Server-side only. Never import this file from a client component.
export const anthropic = new Anthropic({
  apiKey: process.env.ANTHROPIC_API_KEY,
});

export const CLAUDE_MODEL = "claude-sonnet-4-6";

/**
 * Calls Claude with a system prompt + user content and expects strict JSON
 * back. Strips markdown code fences defensively and throws on parse failure
 * so callers can decide how to handle/retry.
 */
export async function callClaudeJSON<T>(system: string, userContent: string): Promise<T> {
  const response = await anthropic.messages.create({
    model: CLAUDE_MODEL,
    max_tokens: 4096,
    system,
    messages: [{ role: "user", content: userContent }],
  });

  const textBlock = response.content.find((b) => b.type === "text");
  const raw = textBlock && "text" in textBlock ? textBlock.text : "";
  const cleaned = raw.replace(/^```json\s*/i, "").replace(/```\s*$/i, "").trim();

  try {
    return JSON.parse(cleaned) as T;
  } catch (err) {
    throw new Error(`Claude did not return valid JSON: ${cleaned.slice(0, 300)}`);
  }
}
